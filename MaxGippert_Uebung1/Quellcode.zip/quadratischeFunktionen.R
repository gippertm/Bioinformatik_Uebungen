##Kommentare

##Quadratische Funktionen
##Parameter
a <- 2
b <- -1
c <- -4

##L�sungen
lsg_1 <- (-((b/a)/2)+sqrt((b/a)^2/4-(c/a)))
lsg_2 <- (-((b/a)/2)-sqrt((b/a)^2/4-(c/a)))

##Ausgabe
lsg_1
lsg_2